CHUNK FINDER LITE — ANDROID PROJECT

This is the Android Studio project for the offline companion app.

IMPORTANT:
- This is not yet a compiled APK.
- It is a local observation notebook/planner for Minecraft Bedrock.
- It does not read Minecraft memory, scan hidden/unloaded chunks, reveal bases, or connect to DonutSMP.
- Sensitivity and radius are preference/planning controls, not an automatic server scanner.

BUILD:
The included GitHub Actions workflow builds a debug APK automatically when this project is pushed to a GitHub repository. The APK appears under Actions > latest successful run > Artifacts.

The app's interface is stored in app/src/main/assets/index.html.
